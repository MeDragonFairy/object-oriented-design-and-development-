(function ($) {
    "use strict";
    var mainApp = {
        slide_fun: function () {
            $('#carousel-example').carousel({
                interval:3000 
            })

        },
        dataTable_fun: function () {

            $('#dataTables-example').dataTable();

        },
       
        custom_fun:function()
        {
         
        },

    }
   
   
    $(document).ready(function () {
        mainApp.slide_fun();
        mainApp.dataTable_fun();
        mainApp.custom_fun();
    });
}(jQuery));


